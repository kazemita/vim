"""Example solution of the E/I population model (network 0, one unseen stimulus) and the two kernels."""
import os
os.environ.setdefault("NP_T", "30"); os.environ.setdefault("NP_SG", "6")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from neural_pop import *

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
W = make_network(0); rng = np.random.default_rng(4242); g = make_stimuli(1, rng)
u = solve_marching(g, W)
t = tf.numpy()
fig, axes = plt.subplots(1, 3, figsize=(12, 3.0), gridspec_kw=dict(width_ratios=[1, 2.2, 2.2]))
s = torch.linspace(0, 8, 400)
for c, col in (("E", "#2f6db5"), ("I", "#c0392b")):
    axes[0].plot(s, kappa(s, **KPAR[c]), color=col, label=f"$\\kappa_{c}$ ($\\delta$={KPAR[c]['delta']}, $\\tau$={KPAR[c]['tau']})")
axes[0].set_xlabel("lag $s$"); axes[0].set_title("synaptic kernels", fontsize=9.5); axes[0].legend(fontsize=7.5, frameon=False)
idx = [0, 5, 11, 33]
cols = ["#1b4f8a", "#2f6db5", "#7fb2e5", "#c0392b"]
for k, c in zip(idx, cols):
    axes[1].plot(t, g[0, :, k], color=c, lw=1.2)
    axes[2].plot(t, u[0, :, k], color=c, lw=1.2, label=("E" if k < 32 else "I") + f" pop. {k}")
axes[1].set_title("external drive $g_i(t)$ (unseen stimulus)", fontsize=9.5); axes[1].set_xlabel("$t$")
axes[2].set_title("solution $u_i(t)$ (Nyström reference)", fontsize=9.5); axes[2].set_xlabel("$t$")
axes[2].legend(fontsize=7.5, frameon=False, ncol=2)
fig.tight_layout()
fig.savefig("paper/figures/network_example.pdf"); fig.savefig("paper/figures/network_example.png", dpi=150)
print("ok")
