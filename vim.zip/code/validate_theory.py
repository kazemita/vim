"""Theory validation on the scalar oscillatory-kernel benchmark (KERNEL=osc KAPPA=3.0).
E3: random, untrained generators always converge (Theorem 1) but constants matter.
E4: measured Jacobian-model error eps_theta (Theorem 2) vs observed iterations, for trained generators
    with latent dimension m in {0,1,2,4,8} and the classical choices."""
import glob
from scipy.linalg import expm
from vim_node import *
torch.set_num_threads(1)
TOL = 1e-5

rng = np.random.default_rng(999); g, ys = make_problems(64, rng)

def iters(hist, ref):
    E = torch.stack([err(u, ref) for u in hist], 0)
    ok = (E < TOL).any(0); hit = (E < TOL).float().argmax(0)
    return E, [int(hit[i]) if ok[i] else -1 for i in range(E.shape[1])]

import sys
out = {}
SKIP_E3 = "--skip-e3" in sys.argv
if SKIP_E3:
    _old = json.load(open("validate_theory.json"))
    for _k in ("E3", "E3_picard", "E3_tol"):
        if _k in _old: out[_k] = _old[_k]
# ---------------- E3: random generators ----------------
gs, yss = g[:16], ys[:16]
e3 = []
for sigma in (() if SKIP_E3 else (0.5, 1.0, 2.0)):
    for k in range(8):
        torch.manual_seed(1000 + 10 * k + int(10 * sigma))
        net = LambdaNet(m=4, phys=True)
        with torch.no_grad():
            for p in net.parameters(): p.normal_(0.0, sigma)
        with torch.no_grad():
            H = run_vim(gs, 80, "learned", net)
            a, b, q, P = net(yss)
            amax = max(a.abs().max().item(), b.abs().max().item(), q.abs().max().item())
        E, it = iters(H, yss)
        e3.append(dict(sigma=sigma, k=k, amax=amax, median_curve=E.median(1).values.tolist(),
                       max_curve=E.amax(1).tolist(), iters=it))
        print(f"E3 sigma={sigma} k={k} max|a,b,q|={amax:6.1f}  converged {sum(i>=0 for i in it)}/16  "
              f"median iters={np.median([i for i in it if i>=0]) if any(i>=0 for i in it) else None}", flush=True)
if not SKIP_E3: out["E3"] = e3

# ---------------- E4: eps_theta vs iterations ----------------
xs = xf
Kxx = Kdiag                                              # K(x,x)
KxM = Kx(XX, TT) * (TT <= XX)                             # dK/dx on the triangle
Wtri = (TT <= XX).double() * dl                           # simple quadrature for the sup-norm integral

def eps_theta(a_star, kmem_star, ystar):
    """exact C->C norm (scalar): max_x |KF' - a| + int_0^x |K_x F' - k_theta| dt"""
    loc = (Kxx * dF(ystar) - a_star).abs()
    mem = ((KxM[None] * dF(ystar)[:, None, :] - kmem_star).abs() * Wtri[None]).sum(-1)
    return (loc + mem).amax(-1), loc.amax(-1), (KxM[None] * dF(ystar)[:, None, :] - kmem_star).abs().amax((-1, -2))

def learned_memory_kernel(net, ystar):
    a, b, q, P = net(ystar)
    if net.m == 0:
        return a, torch.zeros(ystar.shape[0], M, M)
    Pn = P.detach().numpy()
    E = torch.tensor(np.stack([expm(Pn * (k * dl)) for k in range(M)]))   # (M, m, m)
    idx = (torch.arange(M)[:, None] - torch.arange(M)[None, :]).clamp(min=0)
    Ek = E[idx]                                                            # (M, M, m, m)
    kmem = torch.einsum("bxm,xtmn,btn->bxt", b, Ek, q) * (TT <= XX)[None]
    return a, kmem

def jac_norm(step_fn, ystar, gg, eps=1e-6):
    """sup-norm of the discrete Jacobian of the iteration map at the solution (finite differences)."""
    norms = []
    for b in range(ystar.shape[0]):
        base = step_fn(ystar[b:b+1], gg[b:b+1])
        Mk = M - 1
        U = ystar[b:b+1].repeat(Mk, 1) + eps * torch.eye(M)[1:]
        G = gg[b:b+1].repeat(Mk, 1)
        J = ((step_fn(U, G) - base) / eps).T          # J[i,k] = dT_i/du_k  (k >= 1)
        J = J[1:, :]                                  # restrict to u(0)=g(0) subspace (square, M-1)
        pw, Jn = [], torch.eye(Mk)
        for n in range(1, 31):
            Jn = J @ Jn; pw.append(Jn.abs().sum(1).max().item())   # ||J^n||_inf
        nstar = next((n + 1 for n, v in enumerate(pw) if v < TOL), -1)
        norms.append(dict(pow=pw, nstar=nstar))
    return norms

def obs_rate(E):
    """geometric-mean error ratio while 1e-3 > err > 1e-6 (per problem)"""
    r = []
    for b in range(E.shape[1]):
        e = E[:, b].numpy(); ks = [k for k in range(len(e) - 1) if 1e-6 < e[k] < 1e-3 and e[k + 1] > 0]
        r.append(float(np.exp(np.mean([np.log(e[k + 1] / e[k]) for k in ks]))) if ks else float("nan"))
    return r

e4 = {}
nets = {0: "lam_m0_osc3.0phys.pt", 4: "lam_m4_osc3.0phys.pt"}
for f in glob.glob("lam_osc3.0_m*_p1_s*_K8.pt"):
    m = int(f.split("_m")[1].split("_")[0]); s = int(f.split("_s")[1].split("_")[0])
    if s == 0: nets.setdefault(m, f)
ys16, g16 = ys[:32], g[:32]
with torch.no_grad():
    # classical choices
    zero = torch.zeros(32, M)
    for name, a_fn, mode in [("picard", lambda y: zero, "picard"), ("textbook", lambda y: Kxx * dF(y), "local")]:
        eps, el, em = eps_theta(a_fn(ys16), torch.zeros(32, M, M), ys16)
        E, it = iters(run_vim(g16, 40, mode), ys16)
        fn = (lambda U, G: vim_step(U, G, torch.zeros_like(U))) if mode == "picard" else \
             (lambda U, G: vim_step(U, G, Kdiag * dF(U)))
        jn = jac_norm(fn, ys16[:12], g16[:12])
        e4[name] = dict(eps=eps.tolist(), eps_loc=el.tolist(), eps_mem=em.tolist(), iters=it, jac=jn, rate=obs_rate(E))
        print(f"E4 {name:9s} eps={eps.median():.3f} n*={np.median([j['nstar'] for j in jn])} |E|={np.median([j['pow'][0] for j in jn]):.2f} rate={np.nanmedian(obs_rate(E)):.3f} "
              f"iters={np.median([i for i in it if i>=0])}", flush=True)
    for m, f in sorted(nets.items()):
        net = LambdaNet(m=m, phys=True); net.load_state_dict(torch.load(f))
        a_s, kmem = learned_memory_kernel(net, ys16)
        eps, el, em = eps_theta(a_s, kmem, ys16)
        E, it = iters(run_vim(g16, 25, "learned", net), ys16)
        def fn(U, G, net=net):
            a, b, q, P = net(U); return vim_step(U, G, a, b, q, P)
        jn = jac_norm(fn, ys16[:12], g16[:12])
        e4[f"learned_m{m}"] = dict(eps=eps.tolist(), eps_loc=el.tolist(), eps_mem=em.tolist(), iters=it, file=f,
                                   jac=jn, rate=obs_rate(E))
        print(f"E4 learned m={m}  eps={eps.median():.3f} (loc {el.median():.3f}, mem {em.median():.3f}) "
              f"n*={np.median([j['nstar'] for j in jn])} |E|={np.median([j['pow'][0] for j in jn]):.2f} rate={np.nanmedian(obs_rate(E)):.3f} iters={np.median([i for i in it if i>=0])}", flush=True)
    E, it = iters(newton(g16, 12), ys16)
    e4["newton"] = dict(eps=[0.0] * 32, iters=it, rate=obs_rate(E))
out["E4"] = e4
json.dump(out, open("validate_theory.json", "w"))
