"""Neural-population application: train the graph-structured Lagrange multiplier on one network
(random stimuli, residual loss only), then test on unseen stimuli, new networks, a 2x larger
network and stronger coupling.  Run with NP_T=30 NP_SG=6."""
from neural_pop import *
import argparse
ap = argparse.ArgumentParser()
ap.add_argument("--m", type=int, default=6)
ap.add_argument("--steps", type=int, default=300)
ap.add_argument("--unroll", type=int, default=6)
ap.add_argument("--batch", type=int, default=12)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--eval_only", type=str, default="")
ap.add_argument("--init", type=str, default="scratch")   # scratch | pade
args = ap.parse_args()
torch.set_num_threads(1)
TOL = 1e-8
tag = f"np_T{T_END:.0f}_SG{S_GAIN:.0f}_m{args.m}_s{args.seed}" + ("_pade" if args.init == "pade" else "")


def iters_to_tol(hist, ref):
    E = torch.stack([err(u, ref) for u in hist], 0)
    ok = (E < TOL).any(0); hit = (E < TOL).float().argmax(0)
    return dict(median_curve=E.median(1).values.tolist(), max_curve=E.amax(1).tolist(),
                iters=[int(hit[i]) if ok[i] else -1 for i in range(E.shape[1])],
                frac=ok.float().mean().item(),
                med=float(hit[ok].float().median()) if ok.any() else None,
                mx=int(hit[ok].max()) if ok.all() else None)


def evaluate(net, g, W, label, out):
    res = {}
    t0 = time.time(); ref = solve_marching(g, W); t_march = time.time() - t0
    res["marching_time"] = t_march
    with torch.no_grad():
        for meth, n in [("picard", 40), ("pade", 15), ("learned", 15)]:
            t0 = time.time(); H = run(meth, g, W, n, net); dt = (time.time() - t0) / n
            res[meth] = iters_to_tol(H, ref); res[meth]["time_per_iter"] = dt
        t0 = time.time(); H = anderson(g, W, 40); dt = (time.time() - t0) / 40
        res["anderson5"] = iters_to_tol(H, ref); res["anderson5"]["time_per_iter"] = dt
        t0 = time.time(); H = newton(g, W, 12); dt = (time.time() - t0) / 12
        res["newton"] = iters_to_tol(H, ref); res["newton"]["time_per_iter"] = dt
    out[label] = res
    print(f"[{label}]  marching {t_march:.3f}s", flush=True)
    for k in ("picard", "anderson5", "pade", "newton", "learned"):
        r = res[k]
        print(f"   {k:10s} median iters→1e-8 = {r['med']}  worst = {r['mx']}  conv {100*r['frac']:.0f}%  "
              f"({r['time_per_iter']:.3f}s/it)  " + " ".join(f"{e:.0e}" for e in r["median_curve"][:10]), flush=True)


if __name__ == "__main__":
    torch.manual_seed(args.seed); rng = np.random.default_rng(500 + args.seed)
    W0 = make_network(0); typ0 = types_of(W0)
    net = GraphLambdaPade() if args.init == "pade" else GraphLambda(m=args.m)
    log = []; t0 = time.time()
    if args.eval_only:
        net.load_state_dict(torch.load(args.eval_only)); args.steps = 0
    opt = torch.optim.Adam(net.parameters(), lr=3e-3 if args.init == "scratch" else 1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, max(args.steps, 1))
    for it in range(args.steps):
        g = make_stimuli(args.batch, rng)
        u = g; loss = 0.0
        for n in range(args.unroll):
            u = step("learned", u, g, W0, net, typ0)
            loss = loss + torch.log(resid(u, g, W0).pow(2).flatten(1).mean(-1) + 1e-28).mean() / args.unroll
        opt.zero_grad(); loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
        opt.step(); sched.step(); log.append(loss.item())
        if it % 25 == 0 or it == args.steps - 1:
            print(f"{tag} it={it:4d} loss={loss.item():8.3f} ({time.time()-t0:5.0f}s)", flush=True)
    train_time = time.time() - t0
    if not args.eval_only: torch.save(net.state_dict(), f"lam_{tag}.pt")

    out = dict(tag=tag, train_time=train_time, log=log)
    rng = np.random.default_rng(4242)
    evaluate(net, make_stimuli(64, rng), W0, "same_network_unseen_stimuli", out)
    for k in range(1, 4):
        evaluate(net, make_stimuli(16, rng), make_network(100 + k), f"new_network_{k}", out)
    evaluate(net, make_stimuli(16, rng, d=80), make_network(200, d_e=64, d_i=16), "larger_network_d80", out)
    evaluate(net, make_stimuli(16, rng), make_network(0, gain=1.3), "stronger_coupling_x1.3", out)
    json.dump(out, open(f"eval_{tag}.json", "w"))
