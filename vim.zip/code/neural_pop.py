r"""Neural population (Amari / Wilson-Cowan) rate network in Volterra form

    u(t) = g(t) + \int_0^t K(t,s) S(u(s)) ds,   K(t,s)_{ij} = W_{ij} kappa_{c(j)}(t-s),

u in R^d (32 excitatory + 8 inhibitory populations), S = logistic firing-rate function,
kappa_c = delayed gamma(4) synaptic/axonal kernel of the presynaptic type c in {E, I}:
    kappa_c(s) = (s-delta_c)_+^3 exp(-(s-delta_c)/tau_c) / (6 tau_c^4)       (unit mass).
kappa_c is not finitely realisable (pure delay), and kappa_c(0) = 0, so K(t,t) = 0: the textbook
VIM multiplier collapses to lambda = -1 (Picard).

Methods (all share the same RK4 VIM cell with the graph-structured multiplier)
    e    = g + w - u_n
    w_i' = a_i e_i + sum_j W_ij beta_{c(j)} . z_j + H_i[u_n]
    z_j' = P_{c(j)} z_j + q_j e_j,          z_j in R^m
  * picard   : a = q = beta = 0
  * pade     : hand-designed quasi-Newton multiplier: (P_c, q_c, beta_c) = state-space realisation of
               kappa_c' with the delay replaced by a [2/2] Pade approximant, q_j = B_c S'(u_j), a = 0
  * learned  : a, q from a shared per-population MLP of (t, u_j, S'(u_j), type); P_c, beta_c learned
  * newton   : exact Newton-Kantorovich (linearised Volterra system solved by marching)
  * anderson : Anderson(5)-accelerated Picard
  * marching : direct step-by-step Nystrom solution (reference)
"""
import math, time, json, sys, os
import numpy as np
import torch
import torch.nn as nn
from scipy import signal

torch.set_default_dtype(torch.float64)

# ---------------- discretisation ----------------
T_END = float(os.environ.get("NP_T", "20.0")); N = int(round(T_END / 0.1))
h = T_END / N; M = 2 * N + 1; dl = h / 2
tf = torch.linspace(0.0, T_END, M)

def gregory_weights(M, dl):
    Wg = torch.zeros(M, M)
    for j in range(1, M):
        n = j
        if n == 1:   w = [5/12, 8/12, -1/12]
        elif n == 2: w = [1/3, 4/3, 1/3]
        elif n == 3: w = [3/8, 9/8, 9/8, 3/8]
        elif n == 4: w = [14/45, 64/45, 24/45, 64/45, 14/45]
        else:
            w = [1.0] * (n + 1)
            w[0] = w[-1] = 3/8; w[1] = w[-2] = 7/6; w[2] = w[-3] = 23/24
        Wg[j, :len(w)] = torch.tensor(w) * dl
    return Wg

Wg = gregory_weights(M, dl)
SS = (tf[:, None] - tf[None, :])                     # s = t - t'

# ---------------- kernels ----------------
KPAR = {"E": dict(delta=0.4, tau=0.5), "I": dict(delta=0.6, tau=0.8)}

def kappa(s, delta, tau):
    r = torch.clamp(s - delta, min=0.0)
    return r ** 3 * torch.exp(-r / tau) / (6 * tau ** 4)

def dkappa(s, delta, tau):
    r = torch.clamp(s - delta, min=0.0)
    return (r ** 2 / (2 * tau ** 4) - r ** 3 / (6 * tau ** 5)) * torch.exp(-r / tau)

G  = {c: Wg * kappa(SS, **p)  for c, p in KPAR.items()}     # integral form weights
Gx = {c: Wg * dkappa(SS, **p) for c, p in KPAR.items()}     # memory part of H (K(t,t)=0)

# ---------------- firing-rate function ----------------
S_GAIN, S_TH = float(os.environ.get("NP_SG", "4.0")), 0.5
def S(u):  return torch.sigmoid(S_GAIN * (u - S_TH))
def dS(u): s = S(u); return S_GAIN * s * (1 - s)

# ---------------- networks ----------------
D_E, D_I = 32, 8
D = D_E + D_I
IDX = {"E": slice(0, D_E), "I": slice(D_E, D)}
TYPE = torch.cat([torch.zeros(D_E), torch.ones(D_I)])     # 0 = E, 1 = I

def make_network(seed, gain=1.0, d_e=D_E, d_i=D_I, p=0.5, JE=3.0, JI=4.5):
    rng = np.random.default_rng(seed)
    d = d_e + d_i
    W = np.zeros((d, d))
    mask = rng.random((d, d)) < p
    W[:, :d_e] = JE * np.abs(rng.normal(1.0, 0.4, (d, d_e))) / (p * d_e)
    W[:, d_e:] = -JI * np.abs(rng.normal(1.0, 0.4, (d, d_i))) / (p * d_i)
    W *= mask
    return torch.tensor(gain * W)

# ---------------- stimuli ----------------
def make_stimuli(B, rng, d=D):
    t = tf.numpy()
    g = np.zeros((B, M, d))
    g += rng.uniform(-0.6, 0.3, (B, 1, d))                                   # baseline drive
    for _ in range(2):                                                       # two smooth pulses
        on = rng.uniform(0.0, 14.0, (B, 1, 1)); dur = rng.uniform(2.0, 5.0, (B, 1, 1))
        amp = rng.uniform(0.0, 1.5, (B, 1, d)) * (rng.random((B, 1, d)) < 0.5)
        x = np.clip((t[None, :, None] - on) / dur, 0, 1)
        g += amp * np.sin(np.pi * x) ** 2
    om = rng.uniform(0.3, 1.5, (B, 1, 1)); ph = rng.uniform(0, 2 * np.pi, (B, 1, d))
    g += 0.2 * np.sin(om * t[None, :, None] + ph)                            # slow modulation
    return torch.tensor(g)

# ---------------- operators (u: (B,M,d)) ----------------
def cols_of(W):
    """E columns have positive weights, I columns negative (Dale's law) -> type masks from W."""
    isI = (W.sum(0) < 0)
    return {"E": ~isI, "I": isI}

def types_of(W):
    return cols_of(W)["I"].double()

def hist_op(Gd, u, W):
    s = S(u); C = cols_of(W)
    out = 0
    for c in ("E", "I"):
        Y = torch.einsum("xk,bkj->bxj", Gd[c], s[..., C[c]])
        out = out + Y @ W[:, C[c]].T
    return out

def I_op(u, W):  return hist_op(G, u, W)
def H_op(u, W):  return hist_op(Gx, u, W)
def resid(u, g, W): return u - g - I_op(u, W)

# ---------------- direct marching (reference) and Newton ----------------
LAG = int(round(min(p["delta"] for p in KPAR.values()) / dl))   # kernel vanishes for s < LAG*dl

def march(rhs, W, phi):
    """v_j = rhs_j + sum_c sum_{k<j-LAG} G_c[j,k] phi(v_k, k)_c W_c^T, explicit in blocks of LAG."""
    B, M_, d = rhs.shape
    v = rhs.clone()
    PH = torch.zeros_like(rhs)
    C = cols_of(W)
    j = 0
    while j < M_:
        j1 = min(j + LAG, M_)
        acc = 0
        for c in ("E", "I"):
            Y = torch.einsum("xk,bkj->bxj", G[c][j:j1, :j], PH[:, :j, C[c]]) if j > 0 else 0
            acc = acc + (Y @ W[:, C[c]].T if j > 0 else 0)
        v[:, j:j1] = rhs[:, j:j1] + acc
        PH[:, j:j1] = phi(v[:, j:j1], slice(j, j1))
        j = j1
    return v

def solve_marching(g, W):
    return march(g, W, lambda v, sl: S(v))

def newton(g, W, n_iter, u0=None):
    u = g.clone() if u0 is None else u0
    hist = [u]
    for _ in range(n_iter):
        Su = S(u); dSu = dS(u)
        rhs = g + I_op(u, W)                                   # v = g + I[u] + I'[u](v-u)
        uu = u
        v = march(rhs, W, lambda v_, sl: dSu[:, sl] * (v_ - uu[:, sl]))
        u = v; hist.append(u)
    return hist

# ---------------- the RK4 VIM cell ----------------
def vim_step(u, g, W, a=None, q=None, beta=None, P=None):
    """u,g:(B,M,d); a:(B,M,d); q:(B,M,d,m); beta:(d,m); P:(d,m,m)."""
    B = u.shape[0]
    Hn = H_op(u, W)
    lat = q is not None
    d = u.shape[-1]
    w = u.new_zeros(B, d)
    z = u.new_zeros(B, d, q.shape[-1]) if lat else None

    def f(w, z, j):
        e = g[:, j] + w - u[:, j]
        dw = Hn[:, j]
        if a is not None: dw = dw + a[:, j] * e
        if lat:
            dw = dw + (z * beta).sum(-1) @ W.T
            dz = torch.einsum("dmk,bdk->bdm", P, z) + q[:, j] * e[..., None]
            return dw, dz
        return dw, None

    ws, dws = [w], []
    k1w, k1z = f(w, z, 0)
    for i in range(N):
        jm, j1 = 2 * i + 1, 2 * i + 2
        dws.append(k1w)
        k2w, k2z = f(w + 0.5 * h * k1w, (z + 0.5 * h * k1z) if lat else None, jm)
        k3w, k3z = f(w + 0.5 * h * k2w, (z + 0.5 * h * k2z) if lat else None, jm)
        k4w, k4z = f(w + h * k3w, (z + h * k3z) if lat else None, j1)
        w = w + h / 6 * (k1w + 2 * k2w + 2 * k3w + k4w)
        if lat: z = z + h / 6 * (k1z + 2 * k2z + 2 * k3z + k4z)
        ws.append(w)
        k1w, k1z = f(w, z, j1)
    dws.append(k1w)
    Wn = torch.stack(ws, 1); dW = torch.stack(dws, 1)
    Wm = 0.5 * (Wn[:, :-1] + Wn[:, 1:]) + h / 8 * (dW[:, :-1] - dW[:, 1:])
    wf = torch.empty(B, M, d, dtype=u.dtype)
    wf[:, 0::2] = Wn; wf[:, 1::2] = Wm
    return g + wf

# ---------------- integral-form cell (needs only K; exact discrete fixed points) ----------------
def vim_step_int(u, g, W, a=None, q=None, beta=None, P=None):
    """u_{n+1} = Pic(u) + y,  y' = a (y + delta) + sum_j W_ij beta_j.z_j,  z_j' = P_j z_j + q_j (y_j + delta_j),
    delta = Pic(u) - u,  Pic(u) = g + I[u] (Nystrom/Gregory).  a=q=None -> plain Picard."""
    pic = g + I_op(u, W)
    if a is None and q is None:
        return pic
    dlt = pic - u
    B, _, d = u.shape
    lat = q is not None
    y = u.new_zeros(B, d)
    z = u.new_zeros(B, d, q.shape[-1]) if lat else None

    # unbind along time once: indexing [:, j] inside the loop makes autograd allocate full-size grads
    dl_ = dlt.unbind(1)
    a_ = a.unbind(1) if a is not None else None
    q_ = q.unbind(1) if lat else None
    WT = W.T
    PT = P.transpose(1, 2) if lat else None

    def f(y, z, j):
        e = y + dl_[j]
        dy = a_[j] * e if a_ is not None else torch.zeros_like(e)
        if lat:
            dy = dy + (z * beta).sum(-1) @ WT
            dz = (z.unsqueeze(-2) @ PT).squeeze(-2) + q_[j] * e[..., None]
            return dy, dz
        return dy, None

    ys, dys = [y], []
    k1y, k1z = f(y, z, 0)
    for i in range(N):
        jm, j1 = 2 * i + 1, 2 * i + 2
        dys.append(k1y)
        k2y, k2z = f(y + 0.5 * h * k1y, (z + 0.5 * h * k1z) if lat else None, jm)
        k3y, k3z = f(y + 0.5 * h * k2y, (z + 0.5 * h * k2z) if lat else None, jm)
        k4y, k4z = f(y + h * k3y, (z + h * k3z) if lat else None, j1)
        y = y + h / 6 * (k1y + 2 * k2y + 2 * k3y + k4y)
        if lat: z = z + h / 6 * (k1z + 2 * k2z + 2 * k3z + k4z)
        ys.append(y)
        k1y, k1z = f(y, z, j1)
    dys.append(k1y)
    Yn = torch.stack(ys, 1); dY = torch.stack(dys, 1)
    Ym = 0.5 * (Yn[:, :-1] + Yn[:, 1:]) + h / 8 * (dY[:, :-1] - dY[:, 1:])
    yf = torch.empty(B, M, d, dtype=u.dtype)
    yf[:, 0::2] = Yn; yf[:, 1::2] = Ym
    return pic + yf

# ---------------- hand-designed Pade quasi-Newton multiplier ----------------
def pade_realisation(delta, tau, k=2):
    """state-space (A,B,C) of  p e^{-delta p}/(1+tau p)^4  with e^{-delta p} ~ Pade[k/k]."""
    from scipy.interpolate import approximate_taylor_polynomial  # noqa (not used)
    # Pade [k/k] of exp(-x), x = delta p
    num_p, den_p = {1: ([-0.5, 1], [0.5, 1]), 2: ([1/12, -0.5, 1], [1/12, 0.5, 1])}[k]
    num_p = np.array(num_p) * np.array([delta ** (k - i) for i in range(k + 1)])
    den_p = np.array(den_p) * np.array([delta ** (k - i) for i in range(k + 1)])
    gam = np.poly1d([tau, 1]) ** 4
    num = np.polymul(np.poly1d([1, 0]), np.poly1d(num_p))
    den = np.polymul(gam, np.poly1d(den_p))
    A, Bm, C, Dm = signal.tf2ss(num.coeffs, den.coeffs)
    return A, Bm[:, 0], C[0], Dm

def pade_params(m_out=None):
    beta = torch.zeros(D, 6); P = torch.zeros(D, 6, 6); qv = torch.zeros(D, 6)
    for c, p in KPAR.items():
        A, Bv, C, _ = pade_realisation(p["delta"], p["tau"], k=2)
        sl = IDX[c]
        P[sl] = torch.tensor(A); qv[sl] = torch.tensor(Bv); beta[sl] = torch.tensor(C)
    return beta, P, qv

PADE = pade_params()

def pade_type_params():
    out = [torch.zeros(2, 6), torch.zeros(2, 6, 6), torch.zeros(2, 6)]
    for ci, (c, p) in enumerate(KPAR.items()):
        A, Bv, C, _ = pade_realisation(p["delta"], p["tau"], k=2)
        out[0][ci] = torch.tensor(C); out[1][ci] = torch.tensor(A); out[2][ci] = torch.tensor(Bv)
    return out

PADE_T = pade_type_params()

def pade_q(u):
    return dS(u)[..., None] * PADE[2][None, None]          # (B,M,d,6)

# ---------------- learned graph-structured multiplier ----------------
class GraphLambda(nn.Module):
    def __init__(self, m=6, width=48):
        super().__init__()
        self.m = m
        self.body = nn.Sequential(nn.Linear(5, width), nn.Tanh(), nn.Linear(width, width), nn.Tanh(),
                                  nn.Linear(width, 1 + m))
        nn.init.zeros_(self.body[-1].weight); nn.init.zeros_(self.body[-1].bias)
        with torch.no_grad(): self.body[-1].bias[1:] = 1.0     # q != 0, beta = 0 => starts as Picard
        self.logdecay = nn.Parameter(torch.log(torch.linspace(0.3, 3.0, m)).repeat(2, 1))
        self.Poff = nn.Parameter(torch.zeros(2, m, m))
        self.beta = nn.Parameter(torch.zeros(2, m))

    def forward(self, u, typ):
        B, M_, d = u.shape
        tt = tf[None, :, None].expand(B, M_, d) / T_END
        ty = typ[None, None, :].expand(B, M_, d)
        feats = torch.stack([tt, u, dS(u), ty, 1 - ty], -1)
        out = self.body(feats)
        a = out[..., 0]; q = out[..., 1:]
        Pc = -torch.diag_embed(torch.exp(self.logdecay)) + (self.Poff - self.Poff.transpose(1, 2))
        ti = typ.long()
        return a, q, self.beta[ti], Pc[ti]

class GraphLambdaPade(nn.Module):
    """Graph generator anchored at the Pade quasi-Newton multiplier.  The state-space realisation of the
    delayed kernel (beta_c, P_c, qbase_c) is kept fixed (it is physics); the network learns bounded,
    state-dependent corrections:  a_j = A_MAX tanh(NN_a),  q_j = S'(u_j) (qbase_c + Q_MAX tanh(NN_q)) qbase-scaled."""
    A_MAX, Q_MAX = 3.0, 1.0
    def __init__(self, width=48):
        super().__init__()
        self.m = 6
        self.body = nn.Sequential(nn.Linear(5, width), nn.Tanh(), nn.Linear(width, width), nn.Tanh(),
                                  nn.Linear(width, 2))
        nn.init.zeros_(self.body[-1].weight); nn.init.zeros_(self.body[-1].bias)
        self.register_buffer("beta", PADE_T[0].clone())
        self.register_buffer("Pm", PADE_T[1].clone())
        self.register_buffer("qbase", PADE_T[2].clone())

    def forward(self, u, typ):
        B, M_, d = u.shape
        tt = tf[None, :, None].expand(B, M_, d) / T_END
        ty = typ[None, None, :].expand(B, M_, d)
        feats = torch.stack([tt, u, dS(u), ty, 1 - ty], -1)
        out = self.body(feats)
        ti = typ.long()
        a = self.A_MAX * torch.tanh(out[..., 0] / self.A_MAX)
        gain = 1.0 + self.Q_MAX * torch.tanh(out[..., 1])           # scales the Newton-like memory input
        q = (dS(u) * gain)[..., None] * self.qbase[ti][None, None]
        return a, q, self.beta[ti], self.Pm[ti]

def step(method, u, g, W, net=None, typ=None):
    typ = types_of(W) if typ is None else typ
    if method == "picard": return vim_step_int(u, g, W)
    if method == "pade":
        ti = typ.long()
        bet = PADE_T[0][ti]; Pm = PADE_T[1][ti]; qv = PADE_T[2][ti]
        return vim_step_int(u, g, W, None, dS(u)[..., None] * qv[None, None], bet, Pm)
    if method == "learned":
        a, q, beta, P = net(u, typ)
        return vim_step_int(u, g, W, a, q, beta, P)
    if method == "learned_noq":   # ablation: learned local part only (no memory)
        a, q, beta, P = net(u, typ)
        return vim_step_int(u, g, W, a)
    raise ValueError(method)

def run(method, g, W, n_iter, net=None, typ=None):
    u = g.clone(); hist = [u]
    for _ in range(n_iter):
        u = step(method, u, g, W, net, typ); hist.append(u)
    return hist

def anderson(g, W, n_iter, mem=5, base="picard", net=None):
    u = g.clone(); hist = [u]; Fs, Gs = [], []
    B = g.shape[0]
    for k in range(n_iter):
        Gu = step(base, u, g, W, net); f = (Gu - u).reshape(B, -1)
        Fs.append(f); Gs.append(Gu.reshape(B, -1)); Fs, Gs = Fs[-(mem + 1):], Gs[-(mem + 1):]
        if len(Fs) == 1:
            u = Gu
        else:
            dF_ = torch.stack([Fs[i + 1] - Fs[i] for i in range(len(Fs) - 1)], -1)
            dG_ = torch.stack([Gs[i + 1] - Gs[i] for i in range(len(Gs) - 1)], -1)
            gam = torch.linalg.lstsq(dF_, f[..., None], driver="gelsd").solution
            u = (Gs[-1] - (dG_ @ gam)[..., 0]).reshape(g.shape)
        hist.append(u)
    return hist

def err(u, ref): return (u - ref).abs().flatten(1).amax(-1)
