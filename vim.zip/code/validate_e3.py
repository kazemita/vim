"""E3 (Theorem 1): untrained random generators, integral-form cell (exact discrete fixed points),
errors against the Nystrom solution of the same discretisation."""
from vim_node import *
torch.set_num_threads(1)
TOL = 1e-8
rng = np.random.default_rng(999); g, ys = make_problems(64, rng)
gs = g[:16]; ref = nystrom_solve(gs)
e3 = []
with torch.no_grad():
    for sigma in (0.5, 1.0, 2.0):
        for k in range(8):
            torch.manual_seed(1000 + 10 * k + int(10 * sigma))
            net = LambdaNet(m=4, phys=True)
            for p in net.parameters(): p.normal_(0.0, sigma)
            H = run_vim_int(gs, 80, net)
            a, b, q, P = net(ref)
            amax = max(a.abs().max().item(), b.abs().max().item(), q.abs().max().item())
            E = torch.stack([err(u, ref) for u in H], 0)
            ok = (E < TOL).any(0); hit = (E < TOL).float().argmax(0)
            it = [int(hit[i]) if ok[i] else -1 for i in range(16)]
            e3.append(dict(sigma=sigma, k=k, amax=amax, median_curve=E.median(1).values.tolist(),
                           max_curve=E.amax(1).tolist(), iters=it))
            print(f"sigma={sigma} k={k} amax={amax:5.1f} converged {int(ok.sum())}/16 peak {E.max().item():.1e} "
                  f"final {E[-1].median().item():.1e}", flush=True)
    E = torch.stack([err(u, ref) for u in run_vim(gs, 80, "picard")], 0)
    pic = dict(median_curve=E.median(1).values.tolist())
V = json.load(open("validate_theory.json")); V["E3"] = e3; V["E3_picard"] = pic; V["E3_tol"] = TOL
json.dump(V, open("validate_theory.json", "w"))
