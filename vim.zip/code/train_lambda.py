"""Generic trainer/evaluator for the scalar benchmarks.
usage: KERNEL=osc|gauss KAPPA=3.0 python train_lambda.py --m 4 --phys 1 --seed 0 --steps 400 --unroll 8
Saves lam_<tag>.pt and eval_<tag>.json (errors per iteration for 64 unseen problems, all baselines)."""
import argparse
from vim_node import *

ap = argparse.ArgumentParser()
ap.add_argument("--m", type=int, default=4)
ap.add_argument("--phys", type=int, default=1)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--steps", type=int, default=400)
ap.add_argument("--unroll", type=int, default=8)
ap.add_argument("--batch", type=int, default=32)
ap.add_argument("--baselines", type=int, default=1)
ap.add_argument("--eval_only", type=str, default="")
args = ap.parse_args()
torch.set_num_threads(1)
tag = f"{KERNEL}{KAPPA}_m{args.m}_p{args.phys}_s{args.seed}_K{args.unroll}"
EPS, TOL = 1e-16, 1e-5


def anderson(T, g, n_iter, mem=5):
    u = g.clone(); hist = [u]; Fs, Gs = [], []
    for k in range(n_iter):
        Gu = T(u); f = Gu - u
        Fs.append(f); Gs.append(Gu); Fs, Gs = Fs[-(mem + 1):], Gs[-(mem + 1):]
        if len(Fs) == 1:
            u = Gu
        else:
            dF_ = torch.stack([Fs[i + 1] - Fs[i] for i in range(len(Fs) - 1)], -1)
            dG_ = torch.stack([Gs[i + 1] - Gs[i] for i in range(len(Gs) - 1)], -1)
            gam = torch.linalg.lstsq(dF_, f[..., None], driver="gelsd").solution
            u = Gu - (dG_ @ gam)[..., 0]
        u = torch.where(torch.isfinite(u), u, torch.zeros_like(u)).clamp(-50, 50)
        hist.append(u)
    return hist


def summarise(hist, ys):
    E = torch.stack([err(u, ys) for u in hist], 0)
    ok = (E < TOL).any(0); hit = (E < TOL).float().argmax(0)
    return dict(median=E.median(1).values.tolist(), p90=E.quantile(0.9, 1).tolist(),
                iters=[int(hit[i]) if ok[i] else -1 for i in range(E.shape[1])],
                frac=ok.float().mean().item(),
                med_iters=float(hit[ok].float().median()) if ok.any() else None)


if __name__ == "__main__":
    torch.manual_seed(args.seed); rng = np.random.default_rng(100 + args.seed)
    net = LambdaNet(m=args.m, phys=bool(args.phys))
    opt = torch.optim.Adam(net.parameters(), lr=3e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, args.steps)
    t0 = time.time(); log = []
    if args.eval_only:
        net.load_state_dict(torch.load(args.eval_only)); args.steps = 0
    for it in range(args.steps):
        g, _ = make_problems(args.batch, rng)
        u = g; loss = 0.0
        for n in range(args.unroll):
            a, b, q, P = net(u)
            u = vim_step(u, g, a, b, q, P)
            loss = loss + torch.log(resid(u, g).pow(2).mean(-1) + EPS).mean() / args.unroll
        opt.zero_grad(); loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
        opt.step(); sched.step(); log.append(loss.item())
        if it % 50 == 0 or it == args.steps - 1:
            print(f"{tag} it={it:4d} loss={loss.item():8.3f} ({time.time()-t0:5.0f}s)", flush=True)
    train_time = time.time() - t0
    torch.save(net.state_dict(), f"lam_{tag}.pt")

    rng = np.random.default_rng(999); g, ys = make_problems(64, rng)
    out = dict(tag=tag, train_time=train_time, log=log, res={})
    with torch.no_grad():
        out["res"]["learned"] = summarise(run_vim(g, 20, "learned", net), ys)
        if args.baselines:
            out["res"]["picard"] = summarise(run_vim(g, 40, "picard"), ys)
            out["res"]["textbook"] = summarise(run_vim(g, 20, "local"), ys)
            out["res"]["anderson5_picard"] = summarise(
                anderson(lambda u: vim_step(u, g, torch.zeros_like(u)), g, 30), ys)
            out["res"]["newton"] = summarise(newton(g, 12), ys)
    for k, v in out["res"].items():
        print(f"  {k:18s} median iters→1e-5 = {v['med_iters']}  converged {100*v['frac']:.0f}%")
    json.dump(out, open(f"eval_{tag}.json", "w"))
