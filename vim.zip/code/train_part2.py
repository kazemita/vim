"""Part 2: a solution Neural ODE represents the unknown function while the VIM Lagrange
multiplier lambda_theta is learned at the same time (single problem, no solution data).

    u_phi(x) = g(x) + w_phi(x),     dw_phi/dx = f_phi(w_phi, x),  w_phi(0) = 0   (RK4 cell)

Outer loop n (= VIM iteration):
  1. u_n      <- NODE trajectory                                    (forward RK4 march)
  2. theta    <- Adam on  sum_{k=1,2} log||r[T_theta^k u_n]||^2       (lambda learns, on-policy)
  3. targets  <- one pass of the lambda-cell: w~ and its slope w~' at every RK4 node
  4. phi      <- Adam on  ||f_phi(w~_i, x_i) - w~'_i||^2               (slope matching: no
                                                                     back-prop through the march)
Baselines: same loop with lambda = -1 (classic VIM / Picard targets) or textbook lambda,
and a NODE trained directly on the residual ||r[u_phi]||^2 by back-prop through the march
(PINN-style), given the same wall-clock budget as the learned-lambda run."""
from vim_node import *
import os
torch.set_num_threads(1)


class SolNODE(nn.Module):
    def __init__(self, width=64):
        super().__init__()
        self.f = nn.Sequential(nn.Linear(2, width), nn.Tanh(), nn.Linear(width, width), nn.Tanh(),
                               nn.Linear(width, 1))

    def vf(self, w, x):
        return self.f(torch.stack([w, x.expand_as(w) / X], -1))[..., 0]

    def forward(self, Bsz=1):
        w = torch.zeros(Bsz); ws, ds = [w], []
        k1 = self.vf(w, torch.tensor(0.0))
        for i in range(N):
            xi = torch.tensor(i * h)
            ds.append(k1)
            k2 = self.vf(w + 0.5 * h * k1, xi + 0.5 * h)
            k3 = self.vf(w + 0.5 * h * k2, xi + 0.5 * h)
            k4 = self.vf(w + h * k3, xi + h)
            w = w + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
            ws.append(w)
            k1 = self.vf(w, xi + h)
        ds.append(k1)
        Wn = torch.stack(ws, 1); D = torch.stack(ds, 1)
        Wm = 0.5 * (Wn[:, :-1] + Wn[:, 1:]) + h / 8 * (D[:, :-1] - D[:, 1:])
        out = torch.empty(Bsz, M)
        out[:, 0::2] = Wn; out[:, 1::2] = Wm
        return out


xn = xf[0::2]                      # RK4 nodes


def slope_targets(Wn, dW):
    """values + slopes at nodes and (Hermite) midpoints"""
    Wm = 0.5 * (Wn[:, :-1] + Wn[:, 1:]) + h / 8 * (dW[:, :-1] - dW[:, 1:])
    dWm = 1.5 / h * (Wn[:, 1:] - Wn[:, :-1]) - 0.25 * (dW[:, :-1] + dW[:, 1:])
    return torch.cat([Wn, Wm], 1), torch.cat([dW, dWm], 1), torch.cat([xn, xf[1::2]])


def run(variant, g, ys, n_outer=25, phi_steps=300, theta_steps=10, seed=0, lam_init=None,
        time_budget=None, lam_phys=False):
    torch.manual_seed(seed)
    node = SolNODE()
    opt_phi = torch.optim.Adam(node.parameters(), lr=3e-3)
    lr_at = lambda p: 1e-4 + 0.5 * (3e-3 - 1e-4) * (1 + math.cos(math.pi * min(p, 1.0)))  # cosine decay
    lam = LambdaNet(m=4, phys=lam_phys)
    if lam_init is not None: lam.load_state_dict(lam_init)
    opt_th = torch.optim.Adam(lam.parameters(), lr=3e-3)
    t0 = time.time()
    with torch.no_grad(): u = g + node()
    hist = [(0.0, err(u, ys).item())]
    n = 0
    while True:
        prog = n / n_outer if time_budget is None else (time.time() - t0) / time_budget
        for gr in opt_phi.param_groups: gr["lr"] = lr_at(prog)
        if variant == "pinn":
            for _ in range(10):
                u = g + node(); loss = resid(u, g).pow(2).mean()
                opt_phi.zero_grad(); loss.backward(); opt_phi.step()
        else:
            with torch.no_grad(): un = g + node()
            if variant == "learned":
                for _ in range(theta_steps):
                    v = un; L = 0.0
                    for k in range(2):
                        a, b, q, P = lam(v); v = vim_step(v, g, a, b, q, P)
                        L = L + torch.log(resid(v, g).pow(2).mean() + 1e-16)
                    opt_th.zero_grad(); L.backward(); opt_th.step()
            with torch.no_grad():
                if variant == "learned":
                    a, b, q, P = lam(un); _, Wn, dW = vim_step(un, g, a, b, q, P, return_nodes=True)
                elif variant == "picard":
                    _, Wn, dW = vim_step(un, g, torch.zeros_like(un), return_nodes=True)
                elif variant == "local":
                    _, Wn, dW = vim_step(un, g, Kdiag * dF(un), return_nodes=True)
                Wt, dWt, xt = slope_targets(Wn, dW)
            for _ in range(phi_steps):
                pred = node.vf(Wt[0], xt)
                loss = (pred - dWt[0]).pow(2).mean()
                opt_phi.zero_grad(); loss.backward(); opt_phi.step()
        n += 1
        with torch.no_grad(): u = g + node()
        hist.append((time.time() - t0, err(u, ys).item()))
        print(f"  {variant:8s} outer {n:3d}  NODE max-err {hist[-1][1]:.2e}  ({hist[-1][0]:.0f}s)", flush=True)
        if time_budget is None and n >= n_outer: break
        if time_budget is not None and time.time() - t0 > time_budget: break
    return hist, node


if __name__ == "__main__":
    variant, pid = sys.argv[1], int(sys.argv[2])
    rng = np.random.default_rng(2024 + pid)
    g, ys = make_problems(1, rng)
    lam_init, budget, vr = None, None, variant
    theta_steps = 10; lam_phys = False
    if variant in ("learned_pre", "learned_frozen"):   # lambda pre-trained in Part 1 on other problems
        lam_init = torch.load(f"lam_m4_{KERNEL}{KAPPA}.pt"); vr = "learned"
        if variant == "learned_frozen": theta_steps = 0  # no online update: same cost as classic VIM
    if variant == "learned_frozen_phys":               # best Mode-A multiplier (m=4, F' input), frozen
        lam_init = torch.load(f"lam_m4_{KERNEL}{KAPPA}phys.pt"); vr = "learned"; theta_steps = 0; lam_phys = True
    if variant == "pinn":
        budget = float(json.load(open(f"part2_learned_p{pid}.json"))[-1][0])
    hist, node = run(vr, g, ys, n_outer=30, lam_init=lam_init, time_budget=budget, theta_steps=theta_steps,
                     lam_phys=lam_phys)
    json.dump(hist, open(f"part2_{variant}_p{pid}.json", "w"))
    with torch.no_grad(): u = (g + node())[0]
    np.savez(f"part2_{variant}_p{pid}_solution.npz", x=xf.numpy(), u=u.numpy(), y=ys[0].numpy(), g=g[0].numpy())
