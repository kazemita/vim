import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams.update({"font.size": 10, "mathtext.fontset": "cm"})
fig, ax = plt.subplots(figsize=(11.5, 5.2))
ax.set_xlim(0, 11.5); ax.set_ylim(0, 5.2); ax.axis("off")

def box(x, y, w, h, text, fc, fs=10, ec="#1f3b5c"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=fc, ec=ec, lw=1.2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs)

def arr(x0, y0, x1, y1, c="#1f3b5c", rad=0.0, ls="-"):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=11,
                                 color=c, lw=1.2, ls=ls, connectionstyle=f"arc3,rad={rad}"))

ax.add_patch(FancyBboxPatch((0.15, 0.35), 11.2, 4.55, boxstyle="round,pad=0.02,rounding_size=0.15",
                            fc="none", ec="#888", lw=1.0, ls="--"))
ax.text(0.35, 4.62, r"VIM iteration $n$ (weights shared across $n$)", fontsize=10, color="#555")

box(0.4, 2.15, 1.5, 0.9, r"$u_n$ on the grid" "\n" r"$\{x_i, x_{i+1/2}\}$", "#eef2f7")
box(2.5, 3.25, 2.6, 1.05, r"history integral" "\n" r"$\mathcal{P}(u_n)=g+\int_0^x K\,F(u_n)\,dt$" "\n"
    r"$\delta_n=\mathcal{P}(u_n)-u_n$", "#fff4e0", fs=9.5)
box(2.5, 0.75, 2.6, 1.05, r"generator $\mathrm{NN}_\theta(x,u_n,F'(u_n))$" "\n"
    r"$\to a(x),\ b(x),\ q(x),\ P$", "#e3edfb", fs=9.5)
arr(1.9, 2.8, 2.5, 3.6); arr(1.9, 2.4, 2.5, 1.4)

ax.add_patch(FancyBboxPatch((5.7, 1.0), 3.0, 3.0, boxstyle="round,pad=0.02,rounding_size=0.12",
                            fc="#bfe6ff", ec="#1f3b5c", lw=1.3))
ax.text(7.2, 3.65, "RK4 cell, marched over $x$", ha="center", fontsize=10, fontweight="bold")
ax.text(7.2, 2.55, r"$e = y+\delta_n$" "\n" r"$y' = a\,e + b\,z$" "\n" r"$z' = P\,z + q\,e$" "\n"
        r"$y(0)=0,\ z(0)=0$", ha="center", va="center", fontsize=11)
ax.text(7.2, 1.25, r"$k_1,\dots,k_4\ \to\ (y,z)_{i+1}$", ha="center", fontsize=9.5)
arr(5.1, 3.7, 5.7, 3.3); arr(5.1, 1.3, 5.7, 1.7)
arr(8.55, 0.98, 5.85, 0.98, rad=-0.25)
ax.text(7.2, 0.45, r"$(y,z)_i \to (y,z)_{i+1}$", ha="center", fontsize=9)

box(9.25, 2.05, 1.9, 1.1, r"$u_{n+1}=\mathcal{P}(u_n)+y$", "#e7f6e7", fs=10.5)
arr(8.7, 2.6, 9.25, 2.6)
ax.plot([10.2, 10.2, 1.15, 1.15], [3.15, 4.45, 4.45, 3.1], color="#888", lw=1.1, ls="--")
arr(1.15, 3.15, 1.15, 3.06, c="#888")
ax.text(5.6, 4.52, r"$u_{n+1}\to u_n$", fontsize=9.5, color="#555", ha="center")
ax.text(5.75, 0.08, r"$\Lambda(x,s)=-E_1^\top\Phi(x,s)E_1$ (state-space Lagrange multiplier):  $\Lambda(x,x)=-I$ by construction;"
         r"  $a=b=q=0$ gives Picard (classical VIM)", ha="center", fontsize=9.5)
fig.savefig("paper/figures/schematic.pdf", bbox_inches="tight")
fig.savefig("paper/figures/schematic.png", dpi=170, bbox_inches="tight")
print("ok")
