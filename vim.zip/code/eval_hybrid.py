"""Hybrid schedule on the network model: learned (Pade-anchored) generator for the first k iterations, then the
Pade multiplier.  Same test sets and seeds as train_np.py.  Run with NP_T=30 NP_SG=6."""
from neural_pop import *
torch.set_num_threads(1)
TOL = 1e-8
net = GraphLambdaPade(); net.load_state_dict(torch.load("lam_np_T30_SG6_m6_s0_pade.pt"))

def run_hybrid(g, W, k, n_iter=15):
    u = g.clone(); hist = [u]
    for n in range(n_iter):
        u = step("learned" if n < k else "pade", u, g, W, net); hist.append(u)
    return hist

def summ(hist, ref):
    E = torch.stack([err(u, ref) for u in hist], 0)
    ok = (E < TOL).any(0); hit = (E < TOL).float().argmax(0)
    return dict(median_curve=E.median(1).values.tolist(), iters=[int(hit[i]) if ok[i] else -1 for i in range(E.shape[1])],
                frac=ok.float().mean().item(), med=float(hit[ok].float().median()) if ok.any() else None,
                mx=int(hit[ok].max()) if ok.all() else None)

rng = np.random.default_rng(4242)
sets = [("same_network_unseen_stimuli", make_stimuli(64, rng), make_network(0))]
for k in range(1, 4):
    sets.append((f"new_network_{k}", make_stimuli(16, rng), make_network(100 + k)))
sets.append(("larger_network_d80", make_stimuli(16, rng, d=80), make_network(200, d_e=64, d_i=16)))
sets.append(("stronger_coupling_x1.3", make_stimuli(16, rng), make_network(0, gain=1.3)))
out = {}
with torch.no_grad():
    for name, g, W in sets:
        ref = solve_marching(g, W); out[name] = {}
        for k in (2, 3, 4):
            r = summ(run_hybrid(g, W, k), ref); out[name][f"hybrid{k}"] = r
            print(f"[{name}] hybrid k={k}: median {r['med']} worst {r['mx']} conv {100*r['frac']:.0f}%  "
                  + " ".join(f"{e:.0e}" for e in r["median_curve"][:10]), flush=True)
json.dump(out, open("eval_np_hybrid.json", "w"))
