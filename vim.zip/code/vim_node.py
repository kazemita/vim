r"""
Neural-ODE realisation of the Variational Iteration Method (VIM) with a learned
Lagrange multiplier, for nonlinear Volterra integral equations of the 2nd kind

        y(x) = g(x) + \int_0^x K(x,t) F(y(t)) dt ,   x in [0, X].

Key identity
-------------------------------------------------
VIM correction functional (derivative form of the equation):
    u_{n+1}(x) = u_n(x) + \int_0^x lambda(x,s) R[u_n](s) ds,
    R[u](s)    = u'(s) - g'(s) - H[u](s),
    H[u](x)    = d/dx \int_0^x K(x,t)F(u(t))dt = K(x,x)F(u(x)) + \int_0^x K_x(x,t)F(u(t))dt.

Choose lambda(x,s) = -C Phi(x,s) B, where Phi is the transition matrix of a
(learned) linear system.  Then lambda(x,x) = -1 holds by construction (VIM
stationarity condition) and u_{n+1} = g + w is produced by marching ONE ODE

    w' = a(x) (g + w - u_n) + b(x).z + H[u_n](x),     w(0) = 0
    z' = P z + q(x) (g + w - u_n),                     z(0) = 0

with the RK4 cell of the architecture diagram (one VIM iteration = one RK4 pass over x).  (a,b,q) = NN_theta(x, u_n(x)).
  * a = b = q = 0          -> lambda = -1        (classic VIM = Picard)
  * a = K(x,x)F'(u_n), m=0 -> classic "unrestricted" VIM, local Newton
  * learned, m = 0         -> learned scalar Lagrange multiplier
  * learned, m > 0         -> learned memory-aware Lagrange multiplier
Fixed points do not depend on theta: if u_{n+1} = u_n then w' = H[u], i.e. u
solves the integral equation.  Learning lambda changes speed, never the answer.
"""
import math, time, json, sys
import numpy as np
import torch
import torch.nn as nn

torch.set_default_dtype(torch.float64)
torch.manual_seed(0)
np.random.seed(0)

# ----------------------------------------------------------------------------
# Test problem (default): K(x,t) = -3 e^{-(x-t)} cos(3(x-t)),  F(y) = y + sin(2y),  x in [0, 2]
# (KERNEL=gauss gives K = -kappa exp(-(x-t)^2), a non-separable alternative)
# ----------------------------------------------------------------------------
X, N = 2.0, 200                    # N coarse RK4 steps
h = X / N                          # RK4 step
M = 2 * N + 1                      # fine grid (nodes + RK4 midpoints)
dl = h / 2
xf = torch.linspace(0.0, X, M)     # fine grid
import os
KERNEL = os.environ.get("KERNEL", "osc")
KAPPA = float(os.environ.get("KAPPA", "3.0"))
MU, NU = 1.0, 3.0
if KERNEL == "gauss":       # non-separable, infinite rank
    def K(x, t):   return -KAPPA * torch.exp(-(x - t) ** 2)
    def Kx(x, t):  return 2.0 * KAPPA * (x - t) * torch.exp(-(x - t) ** 2)
    def K_np(x, t): return -KAPPA * np.exp(-(x - t) ** 2)
else:                       # damped oscillatory memory, K_x(x,x) != 0
    def K(x, t):   return -KAPPA * torch.exp(-MU * (x - t)) * torch.cos(NU * (x - t))
    def Kx(x, t):
        s = x - t
        return KAPPA * torch.exp(-MU * s) * (MU * torch.cos(NU * s) + NU * torch.sin(NU * s))
    def K_np(x, t): return -KAPPA * np.exp(-MU * (x - t)) * np.cos(NU * (x - t))
def F(y):      return y + torch.sin(2 * y)
def dF(y):     return 1.0 + 2 * torch.cos(2 * y)

# --- 4th-order Gregory quadrature weights on [0, x_j] for every fine node j ---
def gregory_weights(M, dl):
    W = torch.zeros(M, M)
    for j in range(1, M):
        n = j  # number of intervals
        if n == 1:   w = [5/12, 8/12, -1/12]   # quadratic through x0,x1,x2
        elif n == 2: w = [1/3, 4/3, 1/3]
        elif n == 3: w = [3/8, 9/8, 9/8, 3/8]
        elif n == 4: w = [14/45, 64/45, 24/45, 64/45, 14/45]
        else:
            w = [1.0] * (n + 1)
            w[0] = w[-1] = 3/8; w[1] = w[-2] = 7/6; w[2] = w[-3] = 23/24
            if n == 5:  # overlapping corrections: fall back to Simpson+3/8
                w = [1/3, 4/3, 1/3 + 3/8, 9/8, 9/8, 3/8]
        W[j, :len(w)] = torch.tensor(w) * dl
    return W

W = gregory_weights(M, dl)
XX, TT = torch.meshgrid(xf, xf, indexing="ij")
WK  = W * K(XX, TT)                 # for I[u](x_j) = sum_k WK[j,k] F(u_k)
WKx = W * Kx(XX, TT)                # memory part of H
Kdiag = K(xf, xf)

def I_op(u):   return F(u) @ WK.T                            # (B,M)
def H_op(u):   return Kdiag * F(u) + F(u) @ WKx.T
def resid(u, g): return u - g - I_op(u)                       # integral-form residual

# ----------------------------------------------------------------------------
# Problem family (manufactured exact solutions)
# ----------------------------------------------------------------------------
_gl_x, _gl_w = np.polynomial.legendre.leggauss(60)

def sample_params(B, rng):
    return dict(A=rng.uniform(0.5, 1.5, B), om=rng.uniform(1, 3, B),
                ph=rng.uniform(0, 2 * np.pi, B), Bc=rng.uniform(-1, 1, B),
                be=rng.uniform(0.5, 2, B), C=rng.uniform(-0.5, 0.5, B))

def ystar_np(p, x):
    # x: (..., ) broadcast with params of shape (B,1[,1])
    return (p["A"] * np.sin(p["om"] * x + p["ph"]) + p["Bc"] * np.exp(-p["be"] * x) + p["C"])

def make_problems(B, rng):
    p = sample_params(B, rng)
    pe = {k: v[:, None] for k, v in p.items()}
    xn = xf.numpy()
    ys = ystar_np(pe, xn[None, :])                                   # (B,M)
    # exact integral by Gauss-Legendre on [0, x_j] (spectrally accurate)
    T = 0.5 * xn[:, None] * (1 + _gl_x[None, :])                     # (M,Q)
    Wq = 0.5 * xn[:, None] * _gl_w[None, :]
    pe3 = {k: v[:, None, None] for k, v in p.items()}
    yT = ystar_np(pe3, T[None])                                      # (B,M,Q)
    Kv = K_np(xn[:, None], T)
    Fy = yT + np.sin(2 * yT)
    Iex = np.sum(Wq[None] * Kv[None] * Fy, axis=-1)
    g = ys - Iex
    return torch.tensor(g), torch.tensor(ys)

# ----------------------------------------------------------------------------
# The RK4 cell (the user's architecture) carrying one VIM iteration
# ----------------------------------------------------------------------------
class LambdaNet(nn.Module):
    """(x, u_n(x)) -> a, b (m), q (m);  P (m x m) constant.  Zero-init => Picard."""
    def __init__(self, m=0, width=48, phys=False):
        super().__init__()
        self.m, self.phys = m, phys     # phys: also feed F'(u_n) (F is known in a forward problem)
        self.body = nn.Sequential(nn.Linear(3 if phys else 2, width), nn.Tanh(),
                                  nn.Linear(width, width), nn.Tanh(),
                                  nn.Linear(width, 1 + 2 * m))
        nn.init.zeros_(self.body[-1].weight); nn.init.zeros_(self.body[-1].bias)
        if m > 0:
            # b = 0 keeps the start at classic VIM; q != 0 breaks the b*q saddle (else z == 0 forever)
            with torch.no_grad(): self.body[-1].bias[1 + m:] = 1.0
            self.logdecay = nn.Parameter(torch.log(torch.linspace(0.5, 4.0, m)))
            self.Poff = nn.Parameter(torch.zeros(m, m))

    def forward(self, u):                     # u: (B,M)
        B_ = u.shape[0]
        cols = [xf.expand(B_, M) / X, u] + ([dF(u)] if self.phys else [])
        feats = torch.stack(cols, -1)
        out = self.body(feats)
        a = out[..., 0]
        if self.m == 0:
            return a, None, None, None
        b = out[..., 1:1 + self.m]; q = out[..., 1 + self.m:]
        P = -torch.diag(torch.exp(self.logdecay)) + (self.Poff - self.Poff.T)  # stable
        return a, b, q, P


def vim_step(u, g, a, b=None, q=None, P=None, return_nodes=False):
    """One VIM iteration = one pass of the RK4 recurrence over x.
    u, g, a: (B,M) on the fine grid; b,q: (B,M,m); P: (m,m). Returns u_{n+1} (B,M)."""
    Bsz = u.shape[0]
    Hn = H_op(u)
    lat = b is not None
    w = u.new_zeros(Bsz)
    z = u.new_zeros(Bsz, b.shape[-1]) if lat else None

    def f(w, z, j):
        e = g[:, j] + w - u[:, j]
        dw = a[:, j] * e + Hn[:, j]
        if lat:
            dw = dw + (b[:, j] * z).sum(-1)
            dz = z @ P.T + q[:, j] * e[:, None]
            return dw, dz
        return dw, None

    ws, dws = [w], []
    k1w, k1z = f(w, z, 0)
    for i in range(N):
        j0, jm, j1 = 2 * i, 2 * i + 1, 2 * i + 2
        dws.append(k1w)
        k2w, k2z = f(w + 0.5 * h * k1w, (z + 0.5 * h * k1z) if lat else None, jm)
        k3w, k3z = f(w + 0.5 * h * k2w, (z + 0.5 * h * k2z) if lat else None, jm)
        k4w, k4z = f(w + h * k3w, (z + h * k3z) if lat else None, j1)
        w = w + h / 6 * (k1w + 2 * k2w + 2 * k3w + k4w)
        if lat: z = z + h / 6 * (k1z + 2 * k2z + 2 * k3z + k4z)
        ws.append(w)
        k1w, k1z = f(w, z, j1)          # derivative at new node (reused as next k1)
    dws.append(k1w)
    Wn = torch.stack(ws, 1); dW = torch.stack(dws, 1)           # (B,N+1)
    # Hermite (dense-output) values at midpoints, 4th order
    Wm = 0.5 * (Wn[:, :-1] + Wn[:, 1:]) + h / 8 * (dW[:, :-1] - dW[:, 1:])
    wf = torch.empty(Bsz, M, dtype=u.dtype)
    wf[:, 0::2] = Wn; wf[:, 1::2] = Wm
    if return_nodes:            # w and w' at the RK4 nodes (targets for a solution NODE)
        return g + wf, Wn, dW
    return g + wf


def run_vim(g, n_iter, mode, net=None, u0=None):
    u = g.clone() if u0 is None else u0
    hist = [u]
    for _ in range(n_iter):
        if mode == "picard":
            u = vim_step(u, g, torch.zeros_like(u))
        elif mode == "local":
            u = vim_step(u, g, Kdiag * dF(u))
        elif mode == "learned":
            a, b, q, P = net(u)
            u = vim_step(u, g, a, b, q, P)
        hist.append(u)
    return hist


def newton(g, n_iter, u0=None):
    """Reference: exact Newton-Kantorovich on the Nystrom (Gregory) discretisation."""
    u = g.clone() if u0 is None else u0
    hist = [u]
    Id = torch.eye(M)
    for _ in range(n_iter):
        J = WK[None] * dF(u)[:, None, :]                          # (B,M,M) lower-tri
        rhs = g + I_op(u) - (J @ u[..., None])[..., 0]
        u = torch.linalg.solve(Id - J, rhs[..., None])[..., 0]   # (near) lower-triangular
        hist.append(u)
    return hist


def err(u, ys):  return (u - ys).abs().amax(-1)            # max-norm error per problem


def vim_step_int(u, g, a, b=None, q=None, P=None):
    """Integral-form cell (Proposition 2): u_{n+1} = Pic(u) + y,  y' = a (y+delta) + b.z,  z' = P z + q (y+delta),
    delta = Pic(u) - u.  Needs only K, and Nystrom solutions are exact fixed points for every generator."""
    pic = g + I_op(u)
    dlt = pic - u
    Bsz = u.shape[0]
    lat = b is not None
    y = u.new_zeros(Bsz)
    z = u.new_zeros(Bsz, b.shape[-1]) if lat else None
    dl_, a_ = dlt.unbind(1), a.unbind(1)
    b_ = b.unbind(1) if lat else None
    q_ = q.unbind(1) if lat else None

    def f(y, z, j):
        e = y + dl_[j]
        dy = a_[j] * e
        if lat:
            dy = dy + (b_[j] * z).sum(-1)
            return dy, z @ P.T + q_[j] * e[:, None]
        return dy, None

    ys, dys = [y], []
    k1, k1z = f(y, z, 0)
    for i in range(N):
        jm, j1 = 2 * i + 1, 2 * i + 2
        dys.append(k1)
        k2, k2z = f(y + 0.5 * h * k1, (z + 0.5 * h * k1z) if lat else None, jm)
        k3, k3z = f(y + 0.5 * h * k2, (z + 0.5 * h * k2z) if lat else None, jm)
        k4, k4z = f(y + h * k3, (z + h * k3z) if lat else None, j1)
        y = y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        if lat: z = z + h / 6 * (k1z + 2 * k2z + 2 * k3z + k4z)
        ys.append(y)
        k1, k1z = f(y, z, j1)
    dys.append(k1)
    Yn = torch.stack(ys, 1); dY = torch.stack(dys, 1)
    Ym = 0.5 * (Yn[:, :-1] + Yn[:, 1:]) + h / 8 * (dY[:, :-1] - dY[:, 1:])
    yf = torch.empty(Bsz, M, dtype=u.dtype)
    yf[:, 0::2] = Yn; yf[:, 1::2] = Ym
    return pic + yf


def run_vim_int(g, n_iter, net):
    u = g.clone(); hist = [u]
    for _ in range(n_iter):
        a, b, q, P = net(u)
        u = vim_step_int(u, g, a, b, q, P); hist.append(u)
    return hist


def nystrom_solve(g, n_iter=30):
    """Reference Nystrom solution of the Gregory discretisation (Newton to machine precision)."""
    return newton(g, n_iter)[-1]
