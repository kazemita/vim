"""Builds every figure and LaTeX table of the experiments section from the saved JSON results."""
import json, glob, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.makedirs("paper/figures", exist_ok=True); os.makedirs("paper/tables", exist_ok=True)
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "legend.frameon": False})
C = dict(picard="#9e9e9e", anderson="#8e6bbf", textbook="#e08b3a", pade="#2a9d8f",
         learned0="#7fb2e5", learned="#1f4e9c", newton="#222222", scratch="#7fb2e5")

def load(f):
    return json.load(open(f)) if os.path.exists(f) else None

def iters_at(curves_per_problem, tol):
    """first iteration below tol for each problem from per-problem iteration list is not stored for
    every tol; recompute from the stored median curve only where needed (median-of-curve proxy)."""
    for k, e in enumerate(curves_per_problem):
        if e < tol: return k
    return None

def fm(x):
    """median formatting: integers plainly, halves with one decimal (medians of even-sized samples)"""
    if x != x: return "--"
    if x == np.inf: return "$>$budget"
    return f"{x:.0f}" if abs(x - round(x)) < 1e-9 else f"{x:.1f}"

def med_c(iters):
    """censored median: runs that never reached the tolerance (-1) count as +inf"""
    v = np.sort(np.array([np.inf if i < 0 else i for i in iters], float))
    n = len(v)
    if n == 0: return np.nan
    return v[n // 2] if n % 2 else 0.5 * (v[n // 2 - 1] + v[n // 2])

def fmt_iters(r):
    it = [i for i in r["iters"] if i >= 0]
    frac = r.get("frac", len(it) / len(r["iters"]))
    med = med_c(r["iters"])
    p90 = float(np.percentile(it, 90, method="higher")) if it else float("nan")
    s = fm(med) + (f" ({fm(p90)})" if it else "")
    if frac < 0.995: s += f"$^{{\\ast}}${100*frac:.0f}\\%"
    return s

# =====================================================================================
# Table 1 + Figure: scalar benchmarks
# =====================================================================================
bench = {"osc": load("eval_osc3.0_m4_p1_s0_K8.json"), "gauss": load("eval_gauss3.0_m4_p1_s0_K8.json")}
m0 = {"osc": load("eval_osc3.0_m0_p1_s0_K8.json"), "gauss": load("eval_gauss3.0_m0_p1_s0_K8.json")}
rows = [("picard", "Classical VIM, $\\Lambda\\equiv-1$ (Picard)"), ("anderson5_picard", "Anderson(5)-accelerated Picard"),
        ("textbook", "Textbook VIM multiplier"), ("learned_m0", "Learned, $m=0$"), ("learned", "Learned, $m=4$"),
        ("newton", "Newton--Kantorovich (exact Jacobian)")]

def tol_iters(curve, tol):
    k = iters_at(curve, tol); return "--" if k is None else str(k)

lines = []
for key, label in rows:
    cells = []
    for kern in ("osc", "gauss"):
        d = bench[kern]
        if key == "learned_m0":
            r = m0[kern]["res"]["learned"] if m0[kern] else None
        else:
            r = d["res"][key] if d else None
        if r is None:
            cells += ["--", "--"]; continue
        cells += [tol_iters(r["median"], 1e-2), fmt_iters(r)]
    lines.append(f"{label} & " + " & ".join(cells) + " \\\\")
tab = r"""\begin{tabular}{lcccc}
\toprule
 & \multicolumn{2}{c}{oscillatory kernel} & \multicolumn{2}{c}{Gaussian kernel}\\
\cmidrule(lr){2-3}\cmidrule(lr){4-5}
method & $10^{-2}$ & $10^{-5}$ & $10^{-2}$ & $10^{-5}$\\
\midrule
""" + "\n".join(lines) + "\n\\bottomrule\n\\end{tabular}\n"
open("paper/tables/bench.tex", "w").write(tab)

fig, axes = plt.subplots(1, 2, figsize=(10, 3.6), sharey=True)
for ax, kern, title in zip(axes, ("osc", "gauss"), ("oscillatory kernel $-3e^{-s}\\cos 3s$", "Gaussian kernel $-3e^{-s^2}$")):
    d = bench[kern]
    if d is None: continue
    spec = [("picard", "Picard (classical VIM)", C["picard"], "--", "o"),
            ("anderson5_picard", "Anderson(5)", C["anderson"], "-.", "v"),
            ("textbook", "textbook VIM", C["textbook"], "-", "s"),
            ("learned", "learned, $m=4$", C["learned"], "-", "D"),
            ("newton", "Newton", C["newton"], ":", "x")]
    if m0[kern]:
        spec.insert(3, ("m0", "learned, $m=0$", C["learned0"], "-", "^"))
    for key, lab, col, ls, mk in spec:
        r = m0[kern]["res"]["learned"] if key == "m0" else d["res"][key]
        med = np.array(r["median"])[:16]; p90 = np.array(r["p90"])[:16]
        it = np.arange(len(med))
        ax.semilogy(it, med, color=col, ls=ls, marker=mk, ms=3.5, lw=1.5, label=lab)
        ax.fill_between(it, med, p90, color=col, alpha=0.08)
    ax.axhline(1e-5, color="k", lw=0.5, alpha=0.4)
    ax.set_title(title, fontsize=9.5); ax.set_xlabel("iteration $n$"); ax.set_ylim(1e-9, 1e2)
    ax.grid(alpha=0.2)
axes[0].set_ylabel("$\\|u_n-y^\\ast\\|_\\infty$ (median, band to 90th pct.)")
axes[0].legend(fontsize=7.5, loc="lower left")
fig.tight_layout(); fig.savefig("paper/figures/bench.pdf"); fig.savefig("paper/figures/bench.png", dpi=150)
plt.close(fig)

# =====================================================================================
# Table 2: ablations (latent dimension, seeds, unroll length) on the oscillatory kernel
# =====================================================================================
abl = []
for m in (0, 1, 2, 4, 8):
    fs = sorted(glob.glob(f"eval_osc3.0_m{m}_p1_s*_K8.json"))
    for f in fs:
        d = load(f); r = d["res"]["learned"]
        it = [i for i in r["iters"] if i >= 0]
        abl.append(dict(m=m, seed=int(f.split("_s")[1].split("_")[0]), K=8, med=med_c(r["iters"]),
                        mean=np.mean(it) if it else np.nan, frac=r["frac"], n2=iters_at(r["median"], 1e-2)))
f = "eval_osc3.0_m4_p1_s0_K4.json"
if os.path.exists(f):
    r = load(f)["res"]["learned"]; it = [i for i in r["iters"] if i >= 0]
    abl.append(dict(m=4, seed=0, K=4, med=med_c(r["iters"]), mean=np.mean(it), frac=r["frac"], n2=iters_at(r["median"], 1e-2)))
json.dump(abl, open("paper/tables/ablation.json", "w"), indent=1)
lines = []
for m in (0, 1, 2, 4, 8):
    rs = [a for a in abl if a["m"] == m and a["K"] == 8]
    if not rs: continue
    meds = [a["mean"] for a in rs]
    s = f"{np.mean(meds):.2f}" + (f" $\\pm$ {np.std(meds):.2f}" if len(rs) > 1 else "")
    lines.append(f"$m={m}$, $K=8$ & {len(rs)} & {fm(np.median([a['med'] for a in rs]))} & {s} & "
                 f"{np.median([a['n2'] for a in rs]):.0f} & {100*np.mean([a['frac'] for a in rs]):.0f}\\% \\\\")
rs = [a for a in abl if a["K"] == 4]
if rs:
    a = rs[0]
    lines.append(f"$m=4$, $K=4$ & 1 & {fm(a['med'])} & {a['mean']:.2f} & {a['n2']} & {100*a['frac']:.0f}\\% \\\\")
for m in (0, 4):
    f = f"eval_osc3.0_m{m}_p0_s0_K8.json"
    if os.path.exists(f):
        r = load(f)["res"]["learned"]; it = [i for i in r["iters"] if i >= 0]
        lines.append(f"$m={m}$, $K=8$, no $F'$ input & 1 & {fm(med_c(r['iters']))} & {np.mean(it):.2f} & "
                     f"{iters_at(r['median'], 1e-2)} & {100*r['frac']:.0f}\\% \\\\")
tab = r"""\begin{tabular}{lccccc}
\toprule
generator & seeds & median & mean $\pm$ s.d.\ over seeds & iters to $10^{-2}$ & converged\\
\midrule
""" + "\n".join(lines) + "\n\\bottomrule\n\\end{tabular}\n"
open("paper/tables/ablation.tex", "w").write(tab)
print("bench/ablation done")

# =====================================================================================
# Network application: table + figure
# =====================================================================================
nets = {"scratch": load("eval_np_T30_SG6_m6_s0.json"), "pade": load("eval_np_T30_SG6_m6_s0_pade.json"),
        "hybrid": load("eval_np_hybrid.json")}
if nets["scratch"] or nets["pade"]:
    base = nets["pade"] or nets["scratch"]
    sets = [("same_network_unseen_stimuli", "same network, 64 unseen stimuli"),
            ("new_network_1", "new network 1 (16 stimuli)"), ("new_network_2", "new network 2"),
            ("new_network_3", "new network 3"), ("larger_network_d80", "larger network, $d=80$"),
            ("stronger_coupling_x1.3", "coupling $\\times1.3$")]
    cols = [("picard", "Picard"), ("anderson5", "Anderson(5)"), ("newton", "Newton"), ("pade", "Pad\\'e mult."),
            ("scratch", "learned (scratch)"), ("padeinit", "learned (Pad\\'e-anch.)"), ("hybrid", "hybrid")]
    def get(setname, col):
        if col == "scratch": d = nets["scratch"]; key = "learned"
        elif col == "padeinit": d = nets["pade"]; key = "learned"
        elif col == "hybrid": d = nets["hybrid"]; key = "hybrid3"
        else: d = base; key = col
        if d is None or setname not in d: return None
        return d[setname][key]
    def cell(r):
        if r is None: return "--"
        it = [i for i in r["iters"] if i >= 0]
        s = f"{fm(med_c(r['iters']))}/{max(it) if r['frac'] > 0.995 else '--'}" if it else "--"
        if r["frac"] < 0.995: s += f" ({100*r['frac']:.0f}\\%)"
        return s
    lines = []
    for sn, lab in sets:
        lines.append(lab + " & " + " & ".join(cell(get(sn, c)) for c, _ in cols) + " \\\\")
    # early phase: iterations to 1e-2 (median curve), same network
    lines.append("\\midrule")
    e2 = []
    for c, _ in cols:
        r = get("same_network_unseen_stimuli", c)
        e2.append("--" if r is None else str(iters_at(r["median_curve"], 1e-2)))
    lines.append("iterations to $10^{-2}$ (same network) & " + " & ".join(e2) + " \\\\")
    tpi = []
    for c, _ in cols:
        r = get("new_network_1", c)
        tpi.append("--" if (r is None or "time_per_iter" not in r) else f"{r['time_per_iter']:.2f}")
    lines.append("CPU time per iteration [s] (16 problems) & " + " & ".join(tpi) + " \\\\")
    tab = ("\\begin{tabular}{l" + "c" * len(cols) + "}\n\\toprule\ntest set & " + " & ".join(l for _, l in cols)
           + "\\\\\n\\midrule\n" + "\n".join(lines) + "\n\\bottomrule\n\\end{tabular}\n")
    open("paper/tables/network.tex", "w").write(tab)
    json.dump({sn: {c: (lambda r: None if r is None else dict(med=r["med"], mx=r["mx"], frac=r["frac"],
                                                             tpi=r.get("time_per_iter")))(get(sn, c)) for c, _ in cols}
               for sn, _ in sets}, open("paper/tables/network.json", "w"), indent=1)

    fig, axes = plt.subplots(1, 2, figsize=(11, 3.7), gridspec_kw=dict(width_ratios=[1.1, 1.3]))
    ax = axes[0]
    sty = dict(picard=("Picard (= textbook VIM)", C["picard"], "--", "o"), anderson5=("Anderson(5)", C["anderson"], "-.", "v"),
               newton=("Newton", C["newton"], ":", "x"), pade=("Padé multiplier", C["pade"], "-", "s"),
               scratch=("learned (scratch)", C["scratch"], "-", "^"), padeinit=("learned (Padé-anchored)", "#5b7fbf", "-", "D"),
               hybrid=("hybrid: learned → Padé", C["learned"], "-", "P"))
    for c, (lab, col, ls, mk) in sty.items():
        r = get("same_network_unseen_stimuli", c)
        if r is None: continue
        med = np.array(r["median_curve"])[:16]
        ax.semilogy(np.arange(len(med)), np.maximum(med, 1e-16), color=col, ls=ls, marker=mk, ms=3.5, lw=1.5, label=lab)
    ax.axhline(1e-8, color="k", lw=0.5, alpha=0.4)
    ax.set_xlabel("iteration $n$"); ax.set_ylabel("$\\max_{i,t}|u_n-y^\\ast|$ (median of 64)")
    ax.set_title("unseen stimuli, training network ($d=40$)", fontsize=9.5); ax.set_ylim(1e-16, 1e1)
    ax.legend(fontsize=7.5); ax.grid(alpha=0.2)
    ax = axes[1]
    width = 0.115; xs = np.arange(len(sets))
    for k, (c, (lab, col, ls, mk)) in enumerate(sty.items()):
        vals = []
        for sn, _ in sets:
            r = get(sn, c)
            it = [i for i in r["iters"] if i >= 0] if r else []
            vals.append(med_c(r["iters"]) if (r and r["frac"] > 0.5) else np.nan)
        ax.bar(xs + (k - 3) * width, vals, width, color=col, label=lab, alpha=0.9)
    ax.set_xticks(xs); ax.set_xticklabels(["same net.", "new 1", "new 2", "new 3", "$d=80$", "coupling\n×1.3"], fontsize=8)
    ax.set_ylabel("median iterations to $10^{-8}$")
    ax.set_title("generalisation of a multiplier trained on one network", fontsize=9.5)
    ax.grid(alpha=0.2, axis="y")
    fig.tight_layout(); fig.savefig("paper/figures/network.pdf"); fig.savefig("paper/figures/network.png", dpi=150)
    plt.close(fig)
    print("network done")

# =====================================================================================
# Mode B: solution NODE trained with VIM targets
# =====================================================================================
mb = {}
for v in ("picard", "local", "learned", "learned_frozen_phys", "pinn"):
    fs = sorted(glob.glob(f"part2_{v}_p[0-9].json"))
    if fs: mb[v] = {int(f.split("_p")[-1].split(".")[0]): load(f) for f in fs}
if mb:
    lab = dict(picard="classical-VIM targets ($\\Lambda\\equiv-1$)", local="textbook-VIM targets",
               learned_frozen_phys="learned-$\\Lambda$ targets (pre-trained, frozen)",
               learned="learned-$\\Lambda$ targets (trained online)", pinn="residual-trained NODE (no VIM)")
    lines = []
    for v in ("picard", "local", "learned_frozen_phys", "learned", "pinn"):
        if v not in mb: continue
        fin = np.array([h[-1][1] for h in mb[v].values()]); tm = np.array([h[-1][0] for h in mb[v].values()])
        ok = (fin < 1e-2).sum()
        lines.append(f"{lab[v]} & {len(fin)} & {np.median(fin):.1e} & {fin.min():.1e}--{fin.max():.1e} & {ok}/{len(fin)} & {np.median(tm):.0f} \\\\")
    tab = r"""\begin{tabular}{lccccc}
\toprule
training signal & problems & median error & range & error $<10^{-2}$ & CPU time [s]\\
\midrule
""" + "\n".join(lines) + "\n\\bottomrule\n\\end{tabular}\n"
    open("paper/tables/modeb.tex", "w").write(tab)
    fig, ax = plt.subplots(figsize=(6, 3.6))
    sty = dict(picard=(C["picard"], "--"), local=(C["textbook"], "-"), learned_frozen_phys=(C["learned"], "-"),
               learned=(C["learned0"], "-"))
    for v, (col, ls) in sty.items():
        if v not in mb: continue
        H = np.array([[e for t, e in h] for h in mb[v].values()])
        for row in H: ax.semilogy(row, color=col, ls=ls, lw=0.7, alpha=0.3)
        ax.semilogy(np.median(H, 0), color=col, ls=ls, lw=2, label=lab[v].replace("$\\Lambda\\equiv-1$", "Λ≡−1").replace("$\\Lambda$", "Λ") + f" (median of {len(H)})")
    if "pinn" in mb:
        ax.axhline(np.median([h[-1][1] for h in mb["pinn"].values()]), color="#c0392b", ls="-.", lw=1.4,
                   label="residual-trained NODE, same CPU time as online run")
    ax.set_xlabel("outer iteration (VIM step + NODE refit)"); ax.set_ylabel("$\\|u_\\phi-y^\\ast\\|_\\infty$")
    ax.set_ylim(1e-5, 1e2); ax.grid(alpha=0.2); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig("paper/figures/modeb.pdf"); fig.savefig("paper/figures/modeb.png", dpi=150)
    plt.close(fig)
    print("mode B done")

# =====================================================================================
# Validation of the theory (E3 random generators, E4 eps_theta vs iterations)
# =====================================================================================
V = load("validate_theory.json")
if V:
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.7))
    ax = axes[0]
    cmap = {0.5: "#7fb2e5", 1.0: "#2f6db5", 2.0: "#0b2a5c"}
    seen = set()
    for r in V["E3"]:
        lab = f"untrained generator, weight s.d. {r['sigma']}" if r["sigma"] not in seen else None
        seen.add(r["sigma"])
        ax.semilogy(np.maximum(r["median_curve"], 1e-16), color=cmap[r["sigma"]], lw=0.9, alpha=0.85, label=lab)
    if "E3_picard" in V:
        ax.semilogy(np.maximum(V["E3_picard"]["median_curve"], 1e-16), color=C["picard"], ls="--", lw=1.5, label="Picard")
    ax.axhline(V.get("E3_tol", 1e-8), color="k", lw=0.5, alpha=0.4)
    ax.set_xlabel("iteration $n$"); ax.set_ylabel("$\\|u_n-y_h\\|_\\infty$ (median of 16 problems)")
    ax.set_title("untrained generators always converge (Thm. 1)", fontsize=9.5); ax.legend(fontsize=7.2, loc="upper right"); ax.grid(alpha=0.2)
    ax.set_ylim(1e-16, 1e34)
    ax = axes[1]
    E4 = V["E4"]
    order = [k for k in ("picard", "textbook", "learned_m0", "learned_m1", "learned_m2", "learned_m4", "learned_m8", "newton") if k in E4]
    names = dict(picard="Picard", textbook="textbook", newton="Newton")
    for k in order:
        r = E4[k]
        it = [i for i in r["iters"] if i >= 0]
        eps = np.median(r["eps"])
        nm = names.get(k, k.replace("learned_m", "learned $m$="))
        col = C["picard"] if k == "picard" else C["textbook"] if k == "textbook" else C["newton"] if k == "newton" else C["learned"]
        ax.scatter(eps, med_c(r["iters"]), color=col, s=30, zorder=3)
        off = {"learned_m1": (6, -12), "learned_m2": (-44, 8), "learned_m8": (5, -12)}.get(k, (5, 3))
        ax.annotate(nm, (eps, med_c(r["iters"])), textcoords="offset points", xytext=off, fontsize=7.5)
        if "jac" in r:
            ns = [j["nstar"] for j in r["jac"]]
            ax.scatter(eps, med_c(ns), facecolors="none", edgecolors=col, s=30, zorder=3)
    ax.set_xlabel("Jacobian-model error $\\varepsilon_\\theta$ (median)"); ax.set_ylabel("iterations to $10^{-5}$ (median)")
    ax.set_title("observed (filled) and linearised prediction $n^\\ast$ (open)", fontsize=9.5); ax.grid(alpha=0.2)
    fig.tight_layout(); fig.savefig("paper/figures/validation.pdf"); fig.savefig("paper/figures/validation.png", dpi=150)
    plt.close(fig)
    lines = []
    for k in order:
        r = E4[k]; it = [i for i in r["iters"] if i >= 0]
        ns = [j["nstar"] for j in r.get("jac", [])]
        el = np.median(r["eps_loc"]) if "eps_loc" in r else 0.0
        em = np.median(r["eps_mem"]) if "eps_mem" in r else 0.0
        rate = np.nanmedian(r["rate"]) if "rate" in r else np.nan
        lines.append(f"{names.get(k, k.replace('learned_m', 'learned, $m=') + ('$' if k.startswith('learned') else ''))} & "
                     f"{np.median(r['eps']):.2f} & {el:.2f} & {em:.2f} & {fm(med_c(ns)) if ns else '--'} & "
                     f"{fm(med_c(r['iters'][:12]))} ({fm(med_c(r['iters']))}) & {rate:.2f} \\\\")
    tab = r"""\begin{tabular}{lcccccc}
\toprule
multiplier & $\varepsilon_\theta$ & $\varepsilon_{\rm loc}$ & $\varepsilon_{\rm mem}$ & $n^\ast$ (linearised) & observed: same 12 (all 32) & tail ratio\\
\midrule
""" + "\n".join(lines) + "\n\\bottomrule\n\\end{tabular}\n"
    open("paper/tables/validation.tex", "w").write(tab.replace("nan", "--"))
    print("validation done")
